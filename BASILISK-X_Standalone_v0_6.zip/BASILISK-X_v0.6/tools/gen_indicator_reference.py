"""Generates tests/fixtures/indicator_reference.json using pandas (independent of the JS code).
EMA/RSI/ATR use pandas ewm with an explicit SMA seed; ADX is a separate straightforward Python implementation.
Run: python3 tools/gen_indicator_reference.py"""
import json, random
import numpy as np, pandas as pd
random.seed(42)
N=300; t0=1767225600000; px=2300.0; rows=[]
for i in range(N):
    o=px; c=o+random.gauss(0,1.2); h=max(o,c)+abs(random.gauss(0,.5)); l=min(o,c)-abs(random.gauss(0,.5))
    rows.append(dict(time=t0+i*300000,open=round(o,4),high=round(h,4),low=round(l,4),close=round(c,4))); px=c
df=pd.DataFrame(rows)
def nul(s): return [None if pd.isna(x) else float(x) for x in s]
def seeded_ewm(s,period,alpha):
    out=pd.Series(np.nan,index=s.index); first=s.first_valid_index(); start=first+period-1
    seed=s.iloc[first:start+1].mean(); tmp=s.iloc[start:].copy(); tmp.iloc[0]=seed
    out.iloc[start:]=tmp.ewm(alpha=alpha,adjust=False).mean().values; return out
def ema(s,p): return seeded_ewm(s,p,2/(p+1))
close=df.close
# RSI (Wilder): seed = simple average of first 14 gains/losses (diffs 1..14), then Wilder smoothing
d=close.diff(); gain=d.clip(lower=0); loss=(-d).clip(lower=0)
def wilder_from(s,p):  # s has NaN at index 0
    out=pd.Series(np.nan,index=s.index); seed=s.iloc[1:p+1].mean(); tmp=s.iloc[p:].copy(); tmp.iloc[0]=seed
    out.iloc[p:]=tmp.ewm(alpha=1/p,adjust=False).mean().values; return out
ag,al=wilder_from(gain,14),wilder_from(loss,14)
rsi=100-100/(1+ag/al)
pc=close.shift(1)
tr=pd.concat([df.high-df.low,(df.high-pc).abs(),(df.low-pc).abs()],axis=1).max(axis=1); tr.iloc[0]=df.high.iloc[0]-df.low.iloc[0]
atr=seeded_ewm(tr,14,1/14)
ef,es=ema(close,12),ema(close,26); line=ef-es; sig=ema(line,9); hist=line-sig
# ADX, plain loops
h,l,c=df.high.values,df.low.values,df.close.values; p=14; n=len(df)
trv=tr.values; pdm=np.zeros(n); mdm=np.zeros(n)
for i in range(1,n):
    up=h[i]-h[i-1]; dn=l[i-1]-l[i]
    pdm[i]=up if (up>dn and up>0) else 0; mdm[i]=dn if (dn>up and dn>0) else 0
trs,ps,ms=trv[1:p+1].sum(),pdm[1:p+1].sum(),mdm[1:p+1].sum(); dx=[None]*n
for i in range(p,n):
    if i>p: trs=trs-trs/p+trv[i]; ps=ps-ps/p+pdm[i]; ms=ms-ms/p+mdm[i]
    pi,mi=100*ps/trs,100*ms/trs; dx[i]=100*abs(pi-mi)/(pi+mi) if pi+mi else 0
adx=[None]*n; first=2*p-1; v=sum(dx[p:first+1])/p; adx[first]=v
for i in range(first+1,n): v=(v*(p-1)+dx[i])/p; adx[i]=v
out=dict(candles=rows,expected=dict(ema20=nul(ema(close,20)),rsi14=nul(rsi),atr14=nul(atr),macd_line=nul(line),macd_signal=nul(sig),macd_hist=nul(hist),adx14=adx))
json.dump(out,open("tests/fixtures/indicator_reference.json","w"))
print("wrote fixture",N,"candles")
