# Android WebView wrapper source (v0.6)
Offline shell around the local web app. No INTERNET permission, no broker, no market data.
Assets in `app/src/main/assets/www/` are copies of the root web files (re-copy after editing `src/`).

## Free build options
1. **GitHub Actions (no install):** push this folder to a GitHub repo, open Actions > "Build BASILISK-X debug APK" > Run workflow, then download the `BASILISK-X-debug-apk` artifact. Free for public repos; private repos have a monthly free-minute quota.
2. **Android Studio (free):** open this `android/` folder, let Gradle sync, Build > Build APK(s). Output: `app/build/outputs/apk/debug/`.

The debug APK is signed with a debug key: fine for personal sideloading, not for Play Store release.
NOT YET VERIFIED: the Gradle build and on-device behaviour have never been run.
