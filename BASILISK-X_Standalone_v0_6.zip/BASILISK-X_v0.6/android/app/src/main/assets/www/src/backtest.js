/* Deterministic educational backtest. No broker execution.
   Price model: bar OHLC are treated as mid prices. Spread is paid half on entry and half on exit.
   Slippage is an adverse price-unit penalty on EACH fill (entry and exit). Commission is per lot, round turn. */
(function(g){
 const M5=5*60000,M15=15*60000;
 // Index of the last M15 candle that is fully CLOSED by the time the M5 candle at m5Time closes.
 // Candle times are OPEN times. Returns -1 if none.
 function lastCompletedM15(m15,m5Time,from=-1){let j=from;while(j+1<m15.length&&m15[j+1].time+M15<=m5Time+M5)j++;return j;}
 // Exit resolution for one bar. Gap through a level fills at the bar open. SL wins if SL and TP are both inside the bar.
 function resolveExit(t,bar){
  if(t.side==="BUY"){
   if(bar.open<=t.sl)return{price:bar.open,reason:"SL_GAP"};
   if(bar.open>=t.tp)return{price:bar.open,reason:"TP_GAP"};
   if(bar.low<=t.sl)return{price:t.sl,reason:"SL"};
   if(bar.high>=t.tp)return{price:t.tp,reason:"TP"};
  }else{
   if(bar.open>=t.sl)return{price:bar.open,reason:"SL_GAP"};
   if(bar.open<=t.tp)return{price:bar.open,reason:"TP_GAP"};
   if(bar.high>=t.sl)return{price:t.sl,reason:"SL"};
   if(bar.low<=t.tp)return{price:t.tp,reason:"TP"};
  }
  return null;
 }
 // Loss per lot if the stop is hit without a gap, including all costs. Used for position sizing.
 function riskPerUnit(dist,c){return (dist+c.spread+2*c.slippage)*c.contract+c.commission;}
 // t.open = mid price of the entry bar open. t.entry = actual fill (adverse by half spread + slippage).
 function settle(t,exitMid,c){
  const dir=t.side==="BUY"?1:-1,adverse=c.spread/2+c.slippage;
  const exitFill=exitMid-dir*adverse;
  const gross=(exitMid-t.open)*dir*t.units*c.contract;
  const net=(exitFill-t.entry)*dir*t.units*c.contract-c.commission*t.units;
  return{exitFill,gross,costs:gross-net,net};
 }
 function runBacktest(m5,m15,opt={}){
  const I=g.BXIndicators;I.validateCandles(m5);I.validateCandles(m15);
  const risk=Number(opt.riskPct??1),rr=Number(opt.rr??1.5),initial=Number(opt.initialEquity??10000);
  const c={spread:Number(opt.spread??0),slippage:Number(opt.slippage??0),commission:Number(opt.commission??0),contract:Number(opt.contract??100)};
  if(!(risk>0&&risk<=100&&rr>0&&initial>0&&c.spread>=0&&c.slippage>=0&&c.commission>=0&&c.contract>0))throw Error("Invalid backtest settings");
  const c5=m5.map(x=>x.close),c15=m15.map(x=>x.close),e20=I.ema(c5,20),e50=I.ema(c5,50),r=I.rsi(c5,14),a=I.atr(m5,14),m=I.macd(c5),trend=I.ema(c15,20),trades=[];
  let equity=initial,peak=equity,maxDD=0,j=-1,active=null,skippedNoEquity=0;
  for(let i=50;i<m5.length-1;i++){
   j=lastCompletedM15(m15,m5[i].time,j);
   if(active){ // checked on every bar from the entry candle (i+1 of the signal) onward
    const ex=resolveExit(active,m5[i]);
    if(ex){const s=settle(active,ex.price,c);equity+=s.net;peak=Math.max(peak,equity);maxDD=Math.max(maxDD,(peak-equity)/peak*100);trades.push({...active,exit:ex.price,exitFill:s.exitFill,reason:ex.reason,gross:s.gross,costs:s.costs,net:s.net,equity,exitTime:m5[i].time});active=null;}
   }
   if(active||j<0||trend[j]===null||e20[i]===null||e50[i]===null||r[i]===null||a[i]===null||m.hist[i]===null)continue;
   if(equity<=0){skippedNoEquity++;continue;}
   const up=c5[i]>e20[i]&&e20[i]>e50[i]&&r[i]>=50&&r[i]<=70&&m.hist[i]>0&&c15[j]>trend[j];
   const dn=c5[i]<e20[i]&&e20[i]<e50[i]&&r[i]<=50&&r[i]>=30&&m.hist[i]<0&&c15[j]<trend[j];
   if(!up&&!dn)continue;
   const dist=a[i]*1.5;if(!(dist>0))continue;
   const side=up?"BUY":"SELL",dir=up?1:-1,open=m5[i+1].open,entry=open+dir*(c.spread/2+c.slippage);
   const sl=open-dir*dist,tp=open+dir*dist*rr,riskCash=equity*risk/100,units=riskCash/riskPerUnit(dist,c);
   active={side,signalTime:m5[i].time,entryTime:m5[i+1].time,open,entry,sl,tp,units,riskCash,rr};
  }
  const W=trades.filter(t=>t.net>0),L=trades.filter(t=>t.net<=0),gw=W.reduce((s,t)=>s+t.net,0),gl=Math.abs(L.reduce((s,t)=>s+t.net,0));
  return{trades,metrics:{count:trades.length,wins:W.length,losses:L.length,winRate:trades.length?W.length/trades.length*100:0,netPnl:equity-initial,profitFactor:gl?gw/gl:(gw?Infinity:0),maxDrawdownPct:maxDD,endingEquity:equity,skippedNoEquity},openTrade:active};
 }
 // Segment stability report: runs the SAME fixed rules on consecutive chronological segments (fresh warm-up each).
 // This is NOT parameter optimisation and NOT a full walk-forward; it only shows whether results are consistent over time.
 function runSegments(m5,m15,opt={},n=4){
  if(!Number.isInteger(n)||n<2)throw Error("Segments must be an integer >= 2");
  const size=Math.floor(m5.length/n),out=[];
  for(let k=0;k<n;k++){
   const s=m5.slice(k*size,k===n-1?m5.length:(k+1)*size),t0=s[0].time,t1=s[s.length-1].time+M5;
   const s15=m15.filter(x=>x.time>=t0-M15*60&&x.time<t1);
   try{out.push({segment:k+1,from:t0,to:t1,...runBacktest(s,s15,opt).metrics});}catch(e){out.push({segment:k+1,from:t0,to:t1,error:e.message});}
  }
  return out;
 }
 g.BXBacktest={runBacktest,runSegments,lastCompletedM15,resolveExit,riskPerUnit,settle};
})(window);
