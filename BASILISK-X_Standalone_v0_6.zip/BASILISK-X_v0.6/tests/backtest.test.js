
const fs=require("fs"),vm=require("vm"),ctx={window:{}};vm.createContext(ctx);
for(const f of ["src/indicators.js","src/backtest.js"])vm.runInContext(fs.readFileSync(f,"utf8"),ctx);
const B=ctx.window.BXBacktest;
function candles(n,step,inc,amp,period){let t=Date.UTC(2026,0,1),arr=[];for(let i=0;i<n;i++){const p=2300+i*inc+Math.sin(i/period)*amp;const prev=2300+(i-1)*inc+Math.sin((i-1)/period)*amp;const o=i?prev:p,c=p;arr.push({time:t+i*step*60000,open:o,high:Math.max(o,c)+.35,low:Math.min(o,c)-.35,close:c,volume:100});}return arr;}
const m5=candles(1200,5,.03,1,20),m15=candles(400,15,.09,1,20/3);
const opts={riskPct:1,rr:1.5,spread:.2,slippage:.05,commission:7,contract:100};
const a=B.runBacktest(m5,m15,opts),b=B.runBacktest(m5,m15,opts);
const expensive=B.runBacktest(m5,m15,{...opts,commission:70,spread:.5,slippage:.1});
if(JSON.stringify(a.metrics)!==JSON.stringify(b.metrics))throw Error("Backtest is not deterministic");
if(a.trades.length<1)throw Error("No trades produced");
if(!(expensive.metrics.netPnl<a.metrics.netPnl))throw Error("Higher trading costs did not reduce net P/L");
let rejected=false;try{B.runBacktest(m5,m15,{...opts,riskPct:101})}catch(e){rejected=true}if(!rejected)throw Error("Invalid risk accepted");
console.log("PASS: deterministic backtest, trade generation, invalid-risk rejection, and higher-cost penalty");
console.log(JSON.stringify({fixtureTrades:a.metrics.count,fixtureWinRate:a.metrics.winRate,fixtureNetPnl:a.metrics.netPnl,highCostNetPnl:expensive.metrics.netPnl}));
const seg=B.runSegments(m5,m15,opts,3);
if(seg.length!==3||seg.some(s=>s.error))throw Error("Segment report failed: "+JSON.stringify(seg));
console.log("PASS: segment stability report ("+seg.map(s=>s.count+" trades").join(", ")+")");
