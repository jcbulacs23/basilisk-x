// Run: node tests/indicators.test.js
const fs=require("fs"),vm=require("vm"),ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync("src/indicators.js","utf8"),ctx);const I=ctx.window.BXIndicators;
function eq(a,b,t=1e-8){if(Math.abs(a-b)>t)throw Error(`${a} != ${b}`)}
eq(I.ema([1,2,3,4,5],3)[2],2);
eq(I.rsi(Array(15).fill(1).map((x,i)=>i),14)[14],100);
const candles=Array.from({length:40},(_,i)=>({time:i+1,open:10+i,high:11+i,low:9+i,close:10+i}));
if(I.atr(candles,14)[13]===null)throw Error("ATR warmup wrong");
const m=I.macd(Array.from({length:60},(_,i)=>i));if(m.signal[33]===null)throw Error("MACD signal warmup wrong");
const ad=I.adx(candles,14);if(ad[27]===null)throw Error("ADX warmup wrong");
I.validateCandles(candles);
let failed=false;try{I.validateCandles([candles[1],candles[0]])}catch(e){failed=true}if(!failed)throw Error("Timestamp order validation failed");
console.log("PASS: EMA, RSI, ATR, MACD warmup, ADX warmup, OHLC/time validation");