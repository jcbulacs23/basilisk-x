const fs=require("fs"),vm=require("vm"),ctx={window:{}};vm.createContext(ctx);
for(const f of ["src/indicators.js","src/backtest.js"])vm.runInContext(fs.readFileSync(f,"utf8"),ctx);
const B=ctx.window.BXBacktest;let n=0;
const eq=(a,b,m,t=1e-9)=>{if(!(Math.abs(a-b)<=t))throw Error(`${m}: got ${a}, expected ${b}`);n++;};
const is=(a,b,m)=>{if(a!==b)throw Error(`${m}: got ${a}, expected ${b}`);n++;};
const bar=(o,h,l,c)=>({open:o,high:h,low:l,close:c});
const buy={side:"BUY",sl:99,tp:103},sell={side:"SELL",sl:101,tp:97};
// SL/TP resolution
is(B.resolveExit(buy,bar(100,104,98,100)).reason,"SL","BUY collision -> SL first");
is(B.resolveExit(sell,bar(100,102,96,100)).reason,"SL","SELL collision -> SL first");
is(B.resolveExit(buy,bar(100,103.5,99.5,103)).reason,"TP","BUY TP");
is(B.resolveExit(sell,bar(100,100.5,96.5,97)).reason,"TP","SELL TP");
is(B.resolveExit(buy,bar(100,101,99.5,100)),null,"no exit inside range");
let g=B.resolveExit(buy,bar(98,99,97,98));is(g.reason,"SL_GAP","BUY gap below SL");eq(g.price,98,"gap fills at open");
g=B.resolveExit(sell,bar(102,103,101.5,102));is(g.reason,"SL_GAP","SELL gap above SL");eq(g.price,102,"sell gap fills at open");
g=B.resolveExit(buy,bar(104,105,103.5,104));is(g.reason,"TP_GAP","BUY gap above TP");eq(g.price,104,"tp gap fills at open");
// Entry candle can hit SL/TP: exit check uses the same bar that holds the entry (no skipped bar)
is(B.resolveExit(buy,bar(100,100.2,98.9,99.5)).reason,"SL","entry-candle SL touched");
// Costs: spread paid half each side, slippage each side, commission per lot
const c={spread:0.2,slippage:0.05,commission:7,contract:100};
eq(B.riskPerUnit(2,c),(2+0.2+0.1)*100+7,"risk per lot");
const dist=2,units=100/B.riskPerUnit(dist,c);
const t={side:"BUY",open:100,entry:100+0.1+0.05,sl:100-dist,tp:100+dist*1.5,units};
let s=B.settle(t,t.sl,c);eq(s.net,-100,"BUY SL loses exactly riskCash",1e-7);
const ts={side:"SELL",open:100,entry:100-0.15,sl:100+dist,tp:100-dist*1.5,units};
s=B.settle(ts,ts.sl,c);eq(s.net,-100,"SELL SL loses exactly riskCash",1e-7);
s=B.settle(t,t.tp,c);eq(s.net,((dist*1.5-0.2-0.1)*units*100)-7*units,"BUY TP net after costs",1e-7);
eq(s.gross-s.costs,s.net,"gross - costs = net",1e-9);
s=B.settle({...t,entry:t.open},t.tp,{spread:0,slippage:0,commission:0,contract:100});eq(s.costs,0,"zero costs");
// M15 alignment (candle times are OPEN times)
const T=Date.UTC(2026,0,5,10,0),m15=[-1,0,1].map(k=>({time:T+k*15*60000}));// 09:45, 10:00, 10:15
is(B.lastCompletedM15(m15,T),0,"M5 10:00 (closes 10:05): 09:45 done, 10:00 still forming");
is(B.lastCompletedM15(m15,T+5*60000),0,"M5 10:05: 10:00 not yet closed");
is(B.lastCompletedM15(m15,T+10*60000),1,"M5 10:10 closes 10:15 -> M15 10:00 included");
is(B.lastCompletedM15(m15,T+15*60000),1,"M5 10:15: M15 10:15 still forming");
is(B.lastCompletedM15(m15,T+25*60000),2,"M5 10:25 closes 10:30 -> M15 10:15 included");
is(B.lastCompletedM15(m15,T-60*60000),-1,"before any M15 data");
// Input validation
const ok=[{time:1,open:1,high:1,low:1,close:1},{time:2,open:1,high:1,low:1,close:1}];
for(const [name,fn] of [["bad candle",()=>B.runBacktest([{time:1,open:1,high:0,low:2,close:1},ok[1]],ok)],["dup time",()=>B.runBacktest([ok[0],ok[0]],ok)],["negative spread",()=>B.runBacktest(ok,ok,{spread:-1})],["zero rr",()=>B.runBacktest(ok,ok,{rr:0})],["bad segments",()=>B.runSegments(ok,ok,{},1)]]){let r=false;try{fn()}catch(e){r=true}if(!r)throw Error("Accepted invalid input: "+name);n++;}
console.log(`PASS: ${n} edge-case assertions (collision, gaps, entry-candle, costs, sizing, M15 alignment, validation)`);
