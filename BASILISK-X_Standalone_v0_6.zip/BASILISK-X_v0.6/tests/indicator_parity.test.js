const fs=require("fs"),vm=require("vm"),ctx={window:{}};vm.createContext(ctx);
vm.runInContext(fs.readFileSync("src/indicators.js","utf8"),ctx);
const I=ctx.window.BXIndicators,fx=JSON.parse(fs.readFileSync("tests/fixtures/indicator_reference.json","utf8")),e=fx.expected,cs=fx.candles,cl=cs.map(x=>x.close);
const TOL=1e-8;let checked=0;
function cmp(name,js,ref){if(js.length!==ref.length)throw Error(name+": length mismatch");js.forEach((v,i)=>{const r=ref[i];if((v===null)!==(r===null))throw Error(`${name}[${i}]: warm-up mismatch (js=${v}, ref=${r})`);if(v!==null){if(Math.abs(v-r)>TOL)throw Error(`${name}[${i}]: js=${v} ref=${r}`);checked++;}});}
const m=I.macd(cl);
cmp("ema20",I.ema(cl,20),e.ema20);cmp("rsi14",I.rsi(cl,14),e.rsi14);cmp("atr14",I.atr(cs,14),e.atr14);
cmp("macd_line",m.line,e.macd_line);cmp("macd_signal",m.signal,e.macd_signal);cmp("macd_hist",m.hist,e.macd_hist);cmp("adx14",I.adx(cs,14),e.adx14);
console.log(`PASS: JS indicators match pandas/Python reference (tol ${TOL}), ${checked} values compared`);
